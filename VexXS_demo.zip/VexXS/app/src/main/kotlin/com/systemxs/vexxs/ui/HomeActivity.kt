package com.systemxs.vexxs.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.systemxs.vexxs.R

class HomeActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val pager = findViewById<ViewPager2>(R.id.pager)
        pager.adapter = object: FragmentStateAdapter(this) {
            override fun getItemCount() = 2
            override fun createFragment(position: Int): Fragment =
                if (position == 0) HomePageFragment() else AppsPageFragment()
        }

        findViewById<FloatingActionButton>(R.id.fabSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}

class HomePageFragment: Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.page_home, container, false)
        v.findViewById<Button>(R.id.openGallery).setOnClickListener {
            startActivity(Intent(requireContext(), GalleryActivity::class.java))
        }
        return v
    }
}

class AppsPageFragment: Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.page_apps, container, false)
        val rv = v.findViewById<RecyclerView>(R.id.recyclerApps)
        rv.layoutManager = GridLayoutManager(requireContext(), 4)
        rv.adapter = AppsAdapter(listOf(
            AppItem("Teléfono", android.R.drawable.sym_action_call),
            AppItem("Mensajes", android.R.drawable.sym_action_email),
            AppItem("Navegador", android.R.drawable.ic_menu_search),
            AppItem("Notas", android.R.drawable.ic_menu_edit),
            AppItem("Galería", android.R.drawable.ic_menu_gallery),
            AppItem("Ajustes", android.R.drawable.ic_menu_preferences)
        ) ) { item ->
            val intent = when(item.title) {
                "Galería" -> Intent(requireContext(), GalleryActivity::class.java)
                "Ajustes" -> Intent(requireContext(), SettingsActivity::class.java)
                else -> Intent(requireContext(), AppActivity::class.java).putExtra("title", item.title)
            }
            startActivity(intent)
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        return v
    }
}

data class AppItem(val title: String, val icon: Int)

class AppsAdapter(private val items: List<AppItem>, private val onClick: (AppItem)->Unit): RecyclerView.Adapter<AppsVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppsVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return AppsVH(v)
    }
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: AppsVH, position: Int) = holder.bind(items[position], onClick)
}

class AppsVH(v: View): RecyclerView.ViewHolder(v) {
    private val icon = v.findViewById<android.widget.ImageView>(R.id.icon)
    private val label = v.findViewById<android.widget.TextView>(R.id.label)
    fun bind(item: AppItem, onClick: (AppItem)->Unit) {
        icon.setImageResource(item.icon)
        label.text = item.title
        itemView.setOnClickListener { onClick(item) }
    }
}
