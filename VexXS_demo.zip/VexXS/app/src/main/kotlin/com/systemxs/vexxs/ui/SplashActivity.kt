package com.systemxs.vexxs.ui

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.systemxs.vexxs.R

class SplashActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val dots = findViewById<TextView>(R.id.dots)
        ObjectAnimator.ofFloat(dots, "alpha", 1f, 0.2f, 1f).apply {
            duration = 800
            repeatCount = ObjectAnimator.INFINITE
            start()
        }
        dots.postDelayed({
            startActivity(Intent(this, LockScreenActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            finish()
        }, 2500) // anim de arranque rápida (ajustable)
    }
}
