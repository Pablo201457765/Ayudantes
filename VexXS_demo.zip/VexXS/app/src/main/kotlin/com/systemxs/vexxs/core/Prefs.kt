package com.systemxs.vexxs.core

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "vex_prefs"
    private const val DARK = "dark"
    private const val NAV = "nav" // "gestures" or "buttons"

    fun sp(ctx: Context): SharedPreferences = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var Context.darkMode: Boolean
        get() = sp(this).getBoolean(DARK, true)
        set(v) { sp(this).edit().putBoolean(DARK, v).apply() }

    var Context.navigation: String
        get() = sp(this).getString(NAV, "gestures") ?: "gestures"
        set(v) { sp(this).edit().putString(NAV, v).apply() }
}
