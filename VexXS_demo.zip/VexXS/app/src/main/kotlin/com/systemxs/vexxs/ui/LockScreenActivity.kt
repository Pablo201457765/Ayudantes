package com.systemxs.vexxs.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.systemxs.vexxs.R
import java.text.SimpleDateFormat
import java.util.*

class LockScreenActivity: AppCompatActivity() {
    private lateinit var timeView: TextView
    private lateinit var detector: GestureDetector

    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)
        timeView = findViewById(R.id.timeView)
        val fmt = SimpleDateFormat("HH:mm")
        timeView.text = fmt.format(Date())

        detector = GestureDetector(this, object: GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent?, velocityX: Float, velocityY: Float): Boolean {
                if (e1 != null && e2 != null) {
                    if (e2.y < e1.y - 120) { // swipe up
                        startActivity(Intent(this@LockScreenActivity, HomeActivity::class.java))
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                        finish()
                        return true
                    }
                }
                return false
            }
        })
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return detector.onTouchEvent(event) || super.onTouchEvent(event)
    }
}
