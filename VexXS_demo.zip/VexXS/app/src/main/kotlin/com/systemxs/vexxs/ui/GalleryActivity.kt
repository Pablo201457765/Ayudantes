package com.systemxs.vexxs.ui

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.systemxs.vexxs.R

class GalleryActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        val rv = findViewById<RecyclerView>(R.id.recyclerGallery)
        rv.layoutManager = GridLayoutManager(this, 3)
        rv.adapter = GalleryAdapter(intArrayOf(
            android.R.drawable.ic_menu_camera,
            android.R.drawable.ic_menu_gallery,
            android.R.drawable.ic_menu_report_image,
            android.R.drawable.ic_menu_camera
        ))
    }
}

class GalleryAdapter(private val icons: IntArray): RecyclerView.Adapter<GalleryVH>() {
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): GalleryVH {
        val iv = ImageView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, 300)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(16,16,16,16)
        }
        return GalleryVH(iv)
    }
    override fun getItemCount() = icons.size
    override fun onBindViewHolder(holder: GalleryVH, position: Int) {
        (holder.itemView as ImageView).setImageResource(icons[position])
        holder.itemView.setOnClickListener {  }
    }
}

class GalleryVH(v: android.view.View): RecyclerView.ViewHolder(v)
