package com.systemxs.vexxs.ui

import android.os.Bundle
import android.widget.RadioButton
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import com.systemxs.vexxs.R
import com.systemxs.vexxs.core.Prefs.darkMode
import com.systemxs.vexxs.core.Prefs.navigation

class SettingsActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val dark = findViewById<Switch>(R.id.switchDark)
        val navGestures = findViewById<RadioButton>(R.id.navGestures)
        val navButtons = findViewById<RadioButton>(R.id.navButtons)

        dark.isChecked = applicationContext.darkMode
        if (applicationContext.navigation == "gestures") navGestures.isChecked = true else navButtons.isChecked = true

        dark.setOnCheckedChangeListener { _, isChecked ->
            applicationContext.darkMode = isChecked
        }
        navGestures.setOnCheckedChangeListener { _, isChecked -> if (isChecked) applicationContext.navigation = "gestures" }
        navButtons.setOnCheckedChangeListener { _, isChecked -> if (isChecked) applicationContext.navigation = "buttons" }
    }
}
