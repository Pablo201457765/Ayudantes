package com.systemxs.vexxs.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.systemxs.vexxs.R
import com.systemxs.vexxs.databinding.ActivityAppBinding

class AppActivity: AppCompatActivity() {
    private lateinit var vb: ActivityAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vb = ActivityAppBinding.inflate(layoutInflater)
        setContentView(vb.root)
        vb.appTitle.text = intent.getStringExtra("title") ?: "App demo"
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
