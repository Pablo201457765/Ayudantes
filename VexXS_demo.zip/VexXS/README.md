# Vex XS (demo mínimo)
Proyecto Android en Kotlin que simula:
- Pantalla de arranque con animación "VXS..."
- Pantalla de bloqueo (desliza hacia arriba para entrar)
- Inicio con tarjeta de clima y botón a Galería
- Segunda página con grilla de apps
- Transiciones al abrir/cerrar apps
- Ajustes: Modo oscuro (guardado) y modo de navegación (gestos/botones) *placeholder*

## Importar
1. Abre **Android Studio** y selecciona *Open an Existing Project*.
2. Elige la carpeta `VexXS`.
3. Si falta el **Gradle Wrapper**, Android Studio lo generará.
4. Compila y ejecuta.

> Nota: Este es un esqueleto funcional pensado para que lo edites desde el celular/PC.
